<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */
?>

</div><!-- #main -->
</div>
<div id="footer_bg">
<footer id="colophon" role="contentinfo">

<div id="supplementary" class="three">

 <div id="first" class="widget-area" role="complementary">
   <aside id="nav_menu-2" class="widget widget_nav_menu">
     <div class="menu-footer_menu1-container">
       <div class="menu-footer_menu1-container">
       <ul id="menu-footer_menu1" class="menu">
<li>Item name
<ul class="sub-menu">
	<li>Item one</li>	
</ul>
</li>
<li>col 2
<ul class="sub-menu">
<li>Item name
<ul class="sub-menu">
	<li>Item one</li>	
</ul>
</li>

</ul></div>
</div>
   </aside>
 </div><!-- #first .widget-area -->



 <div id="second" class="widget-area" role="complementary">
   <aside id="nav_menu-3" class="widget widget_nav_menu">
     <div class="menu-footer_menu2-container">
       <div class="menu-footer_menu2-container"><ul id="menu-footer_menu2" class="menu"><li id="menu-item-184" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-184"><a href="http://www.p-up.jp/business/">事業案内</a>
<ul class="sub-menu">
</ul>
</li>
<li id="menu-item-192" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-192"><a href="http://www.p-up.jp/storedevelopment/">物件募集</a>
<ul class="sub-menu">
<li>Hello</li>
</ul>
</li>
</ul>
</div>     
</div>
</aside>
 </div><!-- #second .widget-area -->

 <div id="third" class="widget-area" role="complementary">
   <aside id="nav_menu-4" class="widget widget_nav_menu">
     <div class="menu-footer_menu3-container">
       <div class="menu-footer_menu3-container">
       <ul id="menu-footer_menu3" class="menu">
			<li>Item copy</li>
	   </ul>
	</div>     
	</div>
   </aside>
 </div><!-- #third .widget-area -->

	</div><!-- #supplementary -->

			<div id="site-generator">
				<div id="footer_contents">
<?php 
add_filter('nav_menu_css_class', 'my_css_attributes_filter', 100, 1);
add_filter('nav_menu_item_id', 'my_css_attributes_filter', 100, 1);
add_filter('page_css_class', 'my_css_attributes_filter', 100, 1);
function my_css_attributes_filter($var) {
  return is_array($var) ? array() : '';
}
$defaults = array(
	'theme_location'  => 'footer',
	'container'       => false,
	'menu_class'      => 'footer',
	'menu_id'         => 'footer',
	'echo'            => true,
	'fallback_cb'     => false,
	'before'          => '',
	'after'           => '',
	'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
	'depth'           => 0,
	'walker'          => ''
);

wp_nav_menu( $defaults );

 ?>
			 	  <p class="copy">
				<?php do_action( 'twentyfourteen_credits' ); ?>
				<a href="<?php echo esc_url( __( 'http://wordpress.org/', 'twentyfourteen' ) ); ?>"><?php printf( __( 'Proudly powered by %s', 'twentyfourteen' ), 'WordPress' ); ?></a>
			 	  </p>
				</div>
			</div>
	</footer><!-- #colophon -->
</div>

	<?php wp_footer(); ?>

</body>
</html>
